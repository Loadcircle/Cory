@extends('layouts.app')
@section('content')
Listado de tickets
@endsection
