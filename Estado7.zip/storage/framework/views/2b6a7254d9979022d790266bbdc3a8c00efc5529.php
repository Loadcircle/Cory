<?php $__env->startSection('content'); ?>

<div id="local" class="container">
    <h1>{{ tittle }}</h1>
        <a href="#" class="btn btn-primary float-right my-3" data-toggle="modal" data-target="#create">Nuevo Local</a>
        <table class="table table-hover table-stripe ">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Local</th>
                    <th>
                        &nbsp;
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="local in locals">
                    <td>{{ local.id }}</td>
                    <td>{{ local.name }}</td>
                    <td>
                        <a href="#" class="btn btn-warning btn-sm" v-on:click.prevent="editLocal(local)">
                            Editar
                        </a>
                        <a href="#" class="btn btn-danger btn-sm" v-on:click.prevent="deleteLocal(local)">
                            Eliminar
                        </a>
                    </td>
                </tr>
            </tbody>
        </table>
        <nav>
            <ul class="pagination">
                <li class="page-item" v-if="paginate.current_page > 1">
                    <a class="page-link" href="" @click.prevent="changePage(paginate.current_page - 1)">
                        <span>Anterior</span>
                    </a>
                </li>
                <li class="page-item " v-for="page in pagesNumber" v-bind:class="[ page == isActived ? 'active' : '']">
                    <a class="page-link" href="#" @click.prevent="changePage(page)">
                        {{ page }}
                    </a>
                </li>
                <li class="page-item" v-if="paginate.current_page < paginate.last_page">
                    <a class="page-link" href="" @click.prevent="changePage(paginate.current_page + 1)">
                        <span>Siguiente</span>
                    </a>
                </li>
            </ul>
        </nav>
    <?php echo $__env->make('admin.local.create', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.local.edit', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>